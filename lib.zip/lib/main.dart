import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("First Flutter App"),
        ),
        body:Container(
          height:200.0,
          width:double.infinity,
          color:Colors.blue,
          child:Center(
            child:Text(
              'Hello World',
              style:TextStyle(color: Colors.white,fontSize:30),
            ),
          ),
        ),
        // Center(
        //   child: Text('This is a first App',
        //       style: TextStyle(
        //         fontSize: 40.0,
        //         fontStyle: FontStyle.italic,
        //         fontWeight: FontWeight.bold,
        //       )),
        // ),
      ),
    ),
  );
}
