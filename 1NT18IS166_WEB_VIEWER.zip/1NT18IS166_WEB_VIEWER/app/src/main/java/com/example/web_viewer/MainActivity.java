package com.example.web_viewer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView myweb=new WebView(MainActivity.this);


        setContentView(myweb);
        myweb.loadUrl("https://www.nmit.ac.in/");
    }
}