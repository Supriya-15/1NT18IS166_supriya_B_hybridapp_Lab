package com.example.explicitintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    TextView name;
    String n;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        name=findViewById(R.id.textView2);

        n=getIntent().getStringExtra("text");
        Toast.makeText(this, "THIS IS SECOND ACTIVITY"+n, Toast.LENGTH_LONG).show();

        name.setText(n);
    }
}